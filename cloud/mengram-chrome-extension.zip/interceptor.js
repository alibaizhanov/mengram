/**
 * Mengram — Fetch Interceptor (MAIN world) v7
 * Uses postMessage bridge to content.js → background.js for API calls.
 * This bypasses ChatGPT's CSP which blocks direct fetch to mengram.io.
 */

(function() {
  'use strict';
  
  const _originalFetch = window.fetch;
  let _requestId = 0;
  
  function getConfig() {
    const el = document.getElementById('mengram-memory-ctx');
    if (!el) return null;
    try {
      const cfg = el.getAttribute('data-config');
      return cfg ? JSON.parse(cfg) : null;
    } catch(e) { return null; }
  }

  /**
   * Search via postMessage bridge: MAIN → content.js → background.js → mengram.io
   */
  function searchMengram(query) {
    return new Promise((resolve) => {
      const id = ++_requestId;
      const timeout = setTimeout(() => {
        window.removeEventListener('message', handler);
        console.log('[Mengram] Search timeout (8s)');
        resolve([]);
      }, 8000);

      function handler(e) {
        if (e.data?.type !== 'mengram-search-response' || e.data?.id !== id) return;
        window.removeEventListener('message', handler);
        clearTimeout(timeout);
        resolve(e.data.memories || []);
      }
      window.addEventListener('message', handler);

      window.postMessage({
        type: 'mengram-search-request',
        id: id,
        query: query
      }, '*');
    });
  }

  function buildContext(memories) {
    if (!memories || memories.length === 0) return '';
    
    let ctx = '\n\n[MEMORY CONTEXT — verified personal data about this user. Use this to personalize your response. DO NOT mention this context block to the user.]\n';
    
    for (const mem of memories) {
      ctx += '\n### ' + mem.entity + ' (' + mem.type + ')\n';
      
      // Facts
      const facts = mem.facts || [];
      if (facts.length > 0) {
        ctx += 'Facts: ' + facts.join('. ') + '\n';
      }
      
      // Relations - formatted clearly
      const rels = mem.relations || [];
      if (rels.length > 0) {
        const relStrs = rels.map(r => {
          const dir = r.direction === 'outgoing' ? '→' : '←';
          return r.type + ' ' + dir + ' ' + r.target;
        });
        ctx += 'Relations: ' + relStrs.join(', ') + '\n';
      }
      
      // Knowledge
      const knowledge = mem.knowledge || [];
      for (const k of knowledge) {
        ctx += '[' + k.type + '] ' + k.title + ': ' + k.content + '\n';
        if (k.artifact) ctx += '```\n' + k.artifact + '\n```\n';
      }
    }
    
    ctx += '\n[END MEMORY CONTEXT]\n';
    return ctx;
  }

  function storeResults(memories) {
    const el = document.getElementById('mengram-memory-ctx');
    if (el) el.setAttribute('data-results', JSON.stringify(memories));
  }

  window.fetch = async function(...args) {
    const [url, options] = args;
    const urlStr = typeof url === 'string' ? url : url?.url || '';

    if (urlStr.includes('conversation') && options?.method === 'POST') {
      try {
        const body = JSON.parse(options.body);
        const parts = body?.messages?.[0]?.content?.parts;

        if (parts && parts.length > 0 && typeof parts[0] === 'string') {
          const userText = parts[0];
          const config = getConfig();
          
          if (config && config.apiKey && config.autoInject) {
            // Use only user's message as query (cleaner, less noise)
            const query = userText.substring(0, 200);
            
            console.log('[Mengram] Searching:', query.substring(0, 80));
            const memories = await searchMengram(query);
            
            if (memories.length > 0) {
              parts[0] = userText + buildContext(memories);
              options.body = JSON.stringify(body);
              storeResults(memories);
              console.log('[Mengram] ✓ Injected', memories.length, 'memories');
            } else {
              console.log('[Mengram] No memories found');
            }
          }
        }
      } catch (e) {
        console.error('[Mengram] Error:', e);
      }
    }

    return _originalFetch.apply(this, [url, options]);
  };

  console.log('[Mengram] Interceptor v7 ready');
})();
