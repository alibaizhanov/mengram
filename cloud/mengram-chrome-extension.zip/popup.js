// Load saved settings
chrome.storage.local.get(['apiKey', 'cloudUrl', 'autoSave', 'autoInject'], (data) => {
  if (data.apiKey) document.getElementById('apiKey').value = data.apiKey;
  if (data.cloudUrl) document.getElementById('cloudUrl').value = data.cloudUrl;
  document.getElementById('autoSave').checked = data.autoSave !== false;
  document.getElementById('autoInject').checked = data.autoInject !== false;
  
  if (data.apiKey) {
    loadStats(data.cloudUrl || 'https://mengram.io', data.apiKey);
  }
});

// Save settings
document.getElementById('saveBtn').addEventListener('click', async () => {
  const apiKey = document.getElementById('apiKey').value.trim();
  const cloudUrl = document.getElementById('cloudUrl').value.trim() || 'https://mengram.io';
  const autoSave = document.getElementById('autoSave').checked;
  const autoInject = document.getElementById('autoInject').checked;
  const status = document.getElementById('status');

  if (!apiKey) {
    status.textContent = 'API key required';
    status.className = 'status err';
    return;
  }

  // Test connection
  status.textContent = 'Testing connection...';
  status.className = 'status';

  try {
    const res = await fetch(`${cloudUrl}/v1/stats`, {
      headers: { 'Authorization': `Bearer ${apiKey}` }
    });
    
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    chrome.storage.local.set({ apiKey, cloudUrl, autoSave, autoInject }, () => {
      status.textContent = '✓ Connected! Settings saved.';
      status.className = 'status ok';
      loadStats(cloudUrl, apiKey);
    });
  } catch (e) {
    status.textContent = `✗ Connection failed: ${e.message}`;
    status.className = 'status err';
  }
});

async function loadStats(cloudUrl, apiKey) {
  try {
    const res = await fetch(`${cloudUrl}/v1/stats`, {
      headers: { 'Authorization': `Bearer ${apiKey}` }
    });
    if (!res.ok) return;
    const stats = await res.json();

    document.getElementById('statsBox').style.display = 'flex';
    document.getElementById('entityCount').textContent = stats.entities || 0;
    document.getElementById('factCount').textContent = stats.facts || 0;
    document.getElementById('searchCount').textContent = stats.searches || 0;
  } catch (e) {
    // Silently fail
  }
}
